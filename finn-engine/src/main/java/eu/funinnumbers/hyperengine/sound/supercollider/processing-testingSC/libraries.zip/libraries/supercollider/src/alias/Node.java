package supercollider;

public class Node extends SCNode {}
