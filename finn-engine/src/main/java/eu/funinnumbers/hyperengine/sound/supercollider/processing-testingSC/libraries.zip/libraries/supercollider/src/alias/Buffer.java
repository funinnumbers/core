package supercollider;

public class Buffer extends SCBuffer
{
	public Buffer () { super(); }
	public Buffer (SCServer server, int channels) { super(server, channels); }
	public Buffer (int frames, int channels) { super(frames, channels); }
	public Buffer (int channels) { super(channels); }
	public Buffer (SCServer server, int frames, int channels) { super(server, frames, channels); }

}
