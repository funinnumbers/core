package supercollider;

public class Server extends SCServer
{
        public Server() { super(); }
        public Server(String server_ip, int server_port) { super(server_ip, server_port); }
}
