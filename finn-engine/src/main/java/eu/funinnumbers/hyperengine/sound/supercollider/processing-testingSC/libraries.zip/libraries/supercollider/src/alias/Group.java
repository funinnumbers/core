package supercollider;

public class Group extends SCGroup {}
